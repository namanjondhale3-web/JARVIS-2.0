package com.example.jarvis

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONObject
import java.util.Locale

class BrainService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var tts: TextToSpeech
    private var rec: SpeechRecognizer? = null
    private var awaiting = false
    private var busy = false
    private var lang = "en-US"
    private val wake = listOf("jarvis", "jarwis", "jarvish", "जार्विस", "जारविस", "जर्विस", "जार्विज", "जारविज")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (i?.getBooleanExtra("mic", false) == true && !busy) { awaiting = true; tts.stop(); main.post { listen() } }
        i?.getStringExtra("text")?.let { if (!busy) { rec?.destroy(); tts.stop(); run(it) } }
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        JState.running = true; JState.set("idle")
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("j", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "j").setContentTitle("Jarvis: microphone is ON")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        tts = TextToSpeech(this) {
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { main.post { listen() } }
                @Deprecated("x") override fun onError(id: String?) { main.post { listen() } }
            })
            main.post { listen() }
        }
    }

    override fun onDestroy() {
        JState.running = false; JState.set("idle")
        rec?.destroy(); tts.shutdown(); super.onDestroy()
    }

    private fun listen() {
        if (busy) return
        JState.set(if (awaiting) "listening" else "idle")
        rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
                override fun onError(e: Int) { main.postDelayed({ listen() }, 800) }
                override fun onResults(b: Bundle?) {
                    heard(b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: "")
                }
            })
            val it = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            val l = Memory.get(this, "stt", "")
            if (l.isNotEmpty()) it.putExtra(RecognizerIntent.EXTRA_LANGUAGE, l)
            r.startListening(it)
        }
    }

    private fun heard(t: String) {
        val low = t.lowercase()
        val w = wake.firstOrNull { low.contains(it) }
        if (!awaiting && w == null) { main.post { listen() }; return }
        val cmd = (if (w != null) t.substring(low.indexOf(w) + w.length) else t).trim(' ', ',', '.', '!', '?')
        if (cmd.isBlank()) { awaiting = true; speak("Yes ${Memory.get(this, "callme", "boss")}?") } else { awaiting = false; run(cmd) }
    }

    private fun speak(t: String) {
        if (t.isBlank()) { main.post { listen() }; return }
        rec?.destroy(); rec = null
        JState.set("speaking")
        applyVoice()
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    // Picks the best installed voice for the reply language (or the one chosen in Settings).
    private fun applyVoice() {
        tts.setSpeechRate(Memory.get(this, "rate", "1.0").toFloatOrNull() ?: 1f)
        tts.setPitch(Memory.get(this, "pitch", "1.0").toFloatOrNull() ?: 1f)
        val loc = Locale.forLanguageTag(lang)
        tts.language = loc
        val vs = tts.voices?.filter { it.locale.language == loc.language && !it.features.contains("notInstalled") } ?: return
        val want = Memory.get(this, "voice", "")
        val v = vs.firstOrNull { it.name == want } ?: vs.maxByOrNull { it.quality + if (it.isNetworkConnectionRequired) 50 else 0 }
        if (v != null) tts.voice = v
    }

    private fun system(): String {
        val who = Memory.get(this, "callme", "boss")
        return """You are JARVIS, the personal AI assistant of your user. Address the user as "$who".
Personality: ${Memory.get(this, "persona", Memory.PERSONA)}
ALWAYS reply in the language the user spoke (Hindi, Marathi, English, Hinglish...). Keep spoken replies short and natural. Admit when you don't know something.
What you know about the user (category Fiction = made-up stories, NOT facts; Dates and Routine can be temporary; Learned = facts you saved earlier):
${Memory.world(this)}
You control the user's Android phone. Reply ONLY with JSON: {"say":"spoken text","lang":"BCP-47 tag of say, e.g. hi-IN, mr-IN, en-IN","learn":"one new LASTING fact about the user, or empty (never temporary things)","action":{"type":"none|open_app|click|type|scroll|back|home|done","target":"app name or on-screen text","text":"text to type","submit":false}}
For phone tasks do ONE action per reply; you then get RESULT and SCREEN; continue until finished, then use type done. For chat only use type none.
Before sending a message, paying, deleting or anything irreversible: use type none, ask to confirm, and act only after the user says yes."""
    }

    private fun run(cmd: String) {
        busy = true; JState.set("thinking")
        Memory.add(this, "user", cmd)
        Thread {
            var said = ""
            val who = Memory.get(this, "callme", "boss")
            try {
                val convo = Memory.msgs(this)
                for (step in 0 until 12) {
                    val raw = Claude.ask(Memory.key(this), system(), convo)
                    val j = Claude.json(raw)
                    j.optString("say").takeIf { it.isNotBlank() }?.let { said = it }
                    lang = j.optString("lang").ifBlank { lang }
                    Memory.learn(this, j.optString("learn"))
                    val a = j.optJSONObject("action") ?: JSONObject()
                    val type = a.optString("type", "none")
                    if (type == "none" || type == "done") break
                    val svc = JarvisService.instance
                    if (svc == null) { said = "$who, please enable phone control first."; break }
                    val result = svc.act(a)
                    Thread.sleep(1800)
                    convo.put(JSONObject().put("role", "assistant").put("content", raw))
                    convo.put(JSONObject().put("role", "user").put("content", "RESULT: $result\nSCREEN:\n" + svc.screen()))
                }
            } catch (e: Exception) { said = "Sorry $who, error: ${e.message}" }
            Memory.add(this, "assistant", said)
            main.post { busy = false; speak(said) }
        }.start()
    }
}
