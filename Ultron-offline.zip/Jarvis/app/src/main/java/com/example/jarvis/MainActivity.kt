package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.*
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    private val BG = Color.parseColor("#0a0506")
    private val CY = Color.parseColor("#ff2a2a")
    private val PANEL = Color.parseColor("#1b1215")
    private val cats = listOf("Childhood", "People", "Goals", "Likes", "Fears", "Dates", "Routine", "Fiction", "Other")
    private lateinit var body: FrameLayout
    private var orb: OrbView? = null
    private var status: TextView? = null
    private var chatBox: LinearLayout? = null
    private var scroll: ScrollView? = null
    private var pending: (() -> Unit)? = null
    private var editId = 0L
    private var tester: TextToSpeech? = null
    private var modelStatus: TextView? = null
    private var permView: TextView? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(18).toFloat() }
    private fun tv(t: String, size: Float = 15f, color: Int = Color.WHITE) =
        TextView(this).apply { text = t; textSize = size; setTextColor(color) }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE); background = round(CY); setOnClickListener { f() }
    }
    private fun field(h: String, v: String = "") = EditText(this).apply {
        hint = h; setText(v); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        background = round(PANEL); setPadding(dp(14), dp(10), dp(14), dp(10))
    }
    private fun page(vararg v: View) = ScrollView(this).apply {
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(16))
            v.forEach { addView(it, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(8), 0, 0) }) }
        })
    }
    private fun confirm(msg: String, f: () -> Unit) = AlertDialog.Builder(this).setMessage(msg)
        .setPositiveButton("Yes") { _, _ -> f() }.setNegativeButton("No", null).show()
    private fun spinOf(items: List<String>, sel: Int) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items); setSelection(sel.coerceAtLeast(0))
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        Memory.migrate(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        body = FrameLayout(this)
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { setBackgroundColor(PANEL) }
        listOf("💬 Chat", "🧠 My World", "⚙ Settings").forEachIndexed { i, t ->
            nav.addView(Button(this).apply {
                text = t; isAllCaps = false; setTextColor(CY); setBackgroundColor(Color.TRANSPARENT); setOnClickListener { show(i) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        show(0)
    }

    override fun onResume() { super.onResume(); JState.onChange = { refresh() }; refresh() }
    override fun onPause() { JState.onChange = null; super.onPause() }
    override fun onDestroy() { tester?.shutdown(); super.onDestroy() }

    private fun show(i: Int) {
        body.removeAllViews(); orb = null; status = null; chatBox = null; scroll = null; permView = null
        body.addView(when (i) { 0 -> home(); 1 -> world(); else -> settings() })
        refresh()
    }

    private fun refresh() {
        orb?.mode = JState.state
        permView?.text = permText()
        status?.text = when {
            !JState.running -> "Mic OFF · Settings → Start"
            JState.state == "listening" -> "Listening…"
            JState.state == "thinking" -> "Thinking…"
            JState.state == "speaking" -> "Speaking…"
            else -> "Mic ON · say \"Ultron\""
        }
        chatBox?.let { box ->
            box.removeAllViews()
            val h = Memory.history(this)
            if (h.length() == 0) box.addView(tv("Hi! Type below, tap 🎤, or just say \"Ultron\".", 14f, Color.GRAY))
            for (i in 0 until h.length()) { val m = h.getJSONObject(i); box.addView(bubble(m.getString("content"), m.getString("role") == "user")) }
            if (JState.state == "thinking") box.addView(bubble("…", false))
            scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun bubble(t: String, mine: Boolean) = TextView(this).apply {
        text = t; textSize = 15f; setTextIsSelectable(true)
        setTextColor(Color.WHITE)
        background = round(if (mine) CY else PANEL)
        setPadding(dp(14), dp(10), dp(14), dp(10)); maxWidth = (resources.displayMetrics.widthPixels * 0.8).toInt()
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { gravity = if (mine) Gravity.END else Gravity.START; setMargins(0, dp(6), 0, dp(6)) }
    }

    private fun toService(extra: Intent.() -> Unit) {
        if (Memory.useLocal(this)) {
            if (!LocalLlm.ready(this)) { Toast.makeText(this, "Settings → pehle offline model download karo", Toast.LENGTH_LONG).show(); return }
        } else if (Memory.key(this).isBlank()) { Toast.makeText(this, "Settings mein API key daalo (free)", Toast.LENGTH_LONG).show(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pending = { toService(extra) }
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
            return
        }
        startForegroundService(Intent(this, BrainService::class.java).apply(extra))
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) pending?.invoke()
        pending = null
    }

    // ---------------- OFFLINE MODEL ----------------
    private fun permText() = "Phone control: " + (if (JarvisService.instance != null) "✓ connected" else "✗ OFF (turn it on in step 1)") +
        "\nDisplay over other apps: " + (if (Settings.canDrawOverlays(this)) "✓ allowed" else "✗ not allowed (needed to open apps)")

    private fun modelText() = if (LocalLlm.ready(this)) "Model installed ✓ (${LocalLlm.modelFile(this).length() / 1_000_000} MB)"
        else "No offline model yet. Download one: Gemma 4 E2B (~2.5 GB) or Qwen 2.5 1.5B (~1.5 GB)."

    private fun install(src: InputStream, total: Long, label: String) {
        val part = File(filesDir, "model.part")
        src.use { i -> part.outputStream().use { o ->
            val buf = ByteArray(1 shl 16); var n = 0; var done = 0L; var last = 0L
            while (i.read(buf).also { n = it } > 0) {
                o.write(buf, 0, n); done += n
                if (done - last > 10_000_000) { last = done
                    runOnUiThread { modelStatus?.text = "$label ${done / 1_000_000}" + (if (total > 0) " / ${total / 1_000_000}" else "") + " MB" } }
            }
        } }
        val dst = LocalLlm.modelFile(this); LocalLlm.close(); dst.delete(); part.renameTo(dst)
        runOnUiThread { modelStatus?.text = modelText() }
    }

    private fun download(u: String) {
        Thread {
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 20000; c.instanceFollowRedirects = true
                if (c.responseCode !in 200..299) throw Exception("HTTP ${c.responseCode} (wrong link, or login needed)")
                install(c.inputStream, c.contentLengthLong, "Downloading")
            } catch (e: Exception) { runOnUiThread { modelStatus?.text = "Failed: ${e.message}" } }
        }.start()
    }

    @Deprecated("simple")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (req != 7) return
        Thread {
            try { install(contentResolver.openInputStream(uri)!!, 0, "Copying") }
            catch (e: Exception) { runOnUiThread { modelStatus?.text = "Failed: ${e.message}" } }
        }.start()
    }

    // ---------------- CHAT ----------------
    private fun home(): View {
        orb = OrbView(this, 84)
        status = tv("", 12f, CY)
        val title = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv("ULTRON", 18f).apply { typeface = Typeface.create("sans-serif-medium", Typeface.BOLD); letterSpacing = 0.15f })
            addView(status)
        }
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(4), dp(8), dp(4))
            addView(orb, LinearLayout.LayoutParams(dp(84), dp(84)))
            addView(title, LinearLayout.LayoutParams(0, -2, 1f))
            addView(Button(this@MainActivity).apply {
                text = "＋ New"; isAllCaps = false; setTextColor(CY); setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener { confirm("Start a new chat? Current chat will be cleared.") { Memory.clearHistory(this@MainActivity); refresh() } }
            })
        }
        chatBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(4), dp(12), dp(4)) }
        scroll = ScrollView(this).apply { addView(chatBox) }
        val quick = LinearLayout(this).apply { setPadding(dp(8), 0, dp(8), 0) }
        listOf("YouTube", "WhatsApp", "Instagram", "Chrome").forEach { n ->
            quick.addView(btn(n) { toService { putExtra("text", "open $n") } }.apply { textSize = 11f; setSingleLine(); setPadding(0, 0, 0, 0) },
                LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        val input = field("Message Ultron…").apply { setSingleLine(); imeOptions = EditorInfo.IME_ACTION_SEND }
        val sendIt = {
            val t = input.text.toString().trim()
            if (t.isNotEmpty()) { input.setText(""); toService { putExtra("text", t) } }
        }
        input.setOnEditorActionListener { _, _, _ -> sendIt(); true }
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(6))
            addView(input, LinearLayout.LayoutParams(0, -2, 1f))
            addView(btn("🎤") { toService { putExtra("mic", true) } }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(6), 0, 0, 0) })
            addView(btn("➤") { sendIt() }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(6), 0, 0, 0) })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(top, LinearLayout.LayoutParams(-1, -2))
            addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(quick, LinearLayout.LayoutParams(-1, -2))
            addView(row, LinearLayout.LayoutParams(-1, -2))
        }
    }

    // ---------------- MY WORLD ----------------
    private fun world(): View {
        val search = field("🔍 Search memories")
        val spin = spinOf(cats, 0)
        val box = field("Write a memory: who, what, when…").apply { minLines = 3; gravity = Gravity.TOP }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        lateinit var save: Button
        fun render() {
            list.removeAllViews()
            val q = search.text.toString().trim()
            val a = Memory.entries(this)
            for (i in a.length() - 1 downTo 0) {
                val o = a.getJSONObject(i)
                if (q.isNotEmpty() && !(o.getString("text") + " " + o.getString("cat")).contains(q, true)) continue
                val id = o.getLong("id")
                val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = round(PANEL); setPadding(dp(12), dp(10), dp(12), dp(10)) }
                card.addView(tv(o.getString("cat").uppercase(), 11f, CY))
                card.addView(tv(o.getString("text")))
                val row = LinearLayout(this)
                row.addView(Button(this).apply {
                    text = "Edit"; isAllCaps = false
                    setOnClickListener {
                        editId = id; box.setText(o.getString("text"))
                        spin.setSelection(cats.indexOf(o.getString("cat")).coerceAtLeast(0)); save.text = "Update memory"
                    }
                })
                row.addView(Button(this).apply {
                    text = "Delete"; isAllCaps = false
                    setOnClickListener { confirm("Delete this memory?") { Memory.deleteEntry(this@MainActivity, id); render() } }
                })
                card.addView(row)
                list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(8), 0, 0) })
            }
        }
        save = btn("Save memory") {
            val t = box.text.toString().trim()
            if (t.isNotEmpty()) {
                val cat = cats[spin.selectedItemPosition]
                if (editId != 0L) Memory.editEntry(this, editId, cat, t) else Memory.addEntry(this, cat, t)
                editId = 0L; box.setText(""); save.text = "Save memory"; render()
            }
        }
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { render() }
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
        })
        render()
        return page(tv("MY WORLD · Ultron Memory", 20f, CY),
            tv("Ultron reads these to know you. Edit or delete anytime. Use Fiction for made-up stories.", 12f, Color.GRAY),
            spin, box, save, search, list)
    }

    // ---------------- SETTINGS ----------------
    private fun settings(): View {
        val key = field("API key (free Gemini key works)", Memory.key(this))
        val callme = field("What should Ultron call you?", Memory.get(this, "callme", "boss"))
        val persona = field("Personality", Memory.get(this, "persona", Memory.PERSONA)).apply { minLines = 3 }
        val langs = listOf("Phone default" to "", "English (India)" to "en-IN", "Hindi" to "hi-IN", "Marathi" to "mr-IN")
        val lang = spinOf(langs.map { it.first }, langs.indexOfFirst { it.second == Memory.get(this, "stt", "") })
        val rates = listOf("Slow" to "0.8", "Normal" to "1.0", "Fast" to "1.2", "Faster" to "1.4")
        val pitches = listOf("Deep" to "0.85", "Normal" to "1.0", "High" to "1.15")
        val rate = spinOf(rates.map { it.first }, rates.indexOfFirst { it.second == Memory.get(this, "rate", "1.0") })
        val pitch = spinOf(pitches.map { it.first }, pitches.indexOfFirst { it.second == Memory.get(this, "pitch", "1.0") })
        val voices = mutableListOf<Voice>()
        val voiceSpin = spinOf(listOf("Auto (best available)"), 0)
        tester?.shutdown()
        tester = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) runOnUiThread {
                val all = tester?.voices?.filter { it.locale.language in setOf("en", "hi", "mr") && !it.features.contains("notInstalled") }
                    ?.sortedByDescending { it.quality + if (it.isNetworkConnectionRequired) 50 else 0 } ?: emptyList()
                voices.addAll(all)
                voiceSpin.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
                    listOf("Auto (best available)") + all.map { "${it.locale.displayName} · ${if (it.isNetworkConnectionRequired) "online" else "offline"} · q${it.quality / 100}" })
                voiceSpin.setSelection(voices.indexOfFirst { it.name == Memory.get(this, "voice", "") } + 1)
            }
        }
        val engines = listOf("Offline (on-device AI, no key)" to "local", "Online (Gemini/Claude key)" to "online")
        val engineSpin = spinOf(engines.map { it.first }, engines.indexOfFirst { it.second == (if (Memory.useLocal(this)) "local" else "online") })
        modelStatus = tv(modelText(), 12f, Color.LTGRAY)
        permView = tv(permText(), 12f, Color.LTGRAY)
        val link = field("Model link (.litertlm) from HuggingFace")
        fun saveAll() {
            Memory.set(this, "engine", engines[engineSpin.selectedItemPosition].second)
            Memory.setKey(this, key.text.toString().trim())
            Memory.set(this, "callme", callme.text.toString().trim().ifBlank { "boss" })
            Memory.set(this, "persona", persona.text.toString().trim().ifBlank { Memory.PERSONA })
            Memory.set(this, "stt", langs[lang.selectedItemPosition].second)
            Memory.set(this, "rate", rates[rate.selectedItemPosition].second)
            Memory.set(this, "pitch", pitches[pitch.selectedItemPosition].second)
            val i = voiceSpin.selectedItemPosition
            Memory.set(this, "voice", if (i <= 0 || i > voices.size) "" else voices[i - 1].name)
        }
        val privacy = tv("PRIVACY\n" +
            "• The mic is ON only while the Ultron notification is showing. Stop Ultron to turn it off.\n" +
            "• Speech-to-text is done by your phone's Google speech service (it may use Google's servers).\n" +
            "• Only the text of what you say (and screen text during phone tasks) goes to your AI provider.\n" +
            "• Your key, memories and chats are stored on this phone only.", 12f, Color.GRAY)
        return page(
            tv("Settings", 20f, CY), tv("AI engine", 12f, Color.GRAY), engineSpin, modelStatus!!, link,
            btn("⬇ Download model from link") {
                val u = link.text.toString().trim()
                if (u.startsWith("http")) download(u) else Toast.makeText(this, "Paste the model link first", Toast.LENGTH_SHORT).show()
            },
            btn("📁 Pick model file from phone") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 7) },
            btn("Get a free key (opens Google AI Studio)") { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey"))) },
            key, callme, persona,
            tv("Speech language (set Marathi/Hindi if Ultron can't understand you)", 12f, Color.GRAY), lang,
            tv("Voice", 12f, Color.GRAY), voiceSpin,
            tv("Speed", 12f, Color.GRAY), rate, tv("Pitch", 12f, Color.GRAY), pitch,
            btn("▶ Test voice") {
                saveAll()
                val t = tester
                if (t != null) {
                    t.setSpeechRate(rates[rate.selectedItemPosition].second.toFloat()); t.setPitch(pitches[pitch.selectedItemPosition].second.toFloat())
                    val i = voiceSpin.selectedItemPosition
                    if (i in 1..voices.size) t.voice = voices[i - 1]
                    t.speak("Hello! I am Ultron. How can I help you?", TextToSpeech.QUEUE_FLUSH, null, "t")
                }
            },
            btn("Save settings") { saveAll(); Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show() },
            btn(if (JState.running) "■ Stop Ultron" else "▶ Start Ultron (always listening)") {
                saveAll()
                if (JState.running) { stopService(Intent(this, BrainService::class.java)); JState.running = false; JState.set("idle") }
                else toService { }
                body.postDelayed({ show(2) }, 600)
            },
            permView!!,
            btn("1. Enable phone control") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            btn("2. Allow 'Display over other apps'") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) },
            btn("Battery settings (keep Ultron alive)") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) },
            privacy,
            btn("Clear chat history") { confirm("Clear all chat history?") { Memory.clearHistory(this); refresh() } },
            btn("Clear MY WORLD memories") { confirm("Delete all memories?") { Memory.clearWorld(this) } },
            btn("Erase everything (incl. key)") { confirm("Erase ALL data?") { Memory.clearAll(this); show(2) } }
        )
    }
}
