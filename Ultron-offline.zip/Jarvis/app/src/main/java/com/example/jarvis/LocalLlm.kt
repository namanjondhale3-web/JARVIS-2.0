package com.example.jarvis

import android.content.Context
import com.google.ai.edge.litertlm.*
import java.io.File

// Runs a downloaded .litertlm model fully on the phone (no key, no internet).
object LocalLlm {
    private var engine: Engine? = null
    fun modelFile(c: Context) = File(c.filesDir, "model.litertlm")
    fun ready(c: Context) = modelFile(c).let { it.exists() && it.length() > 50_000_000 }

    @Synchronized fun load(c: Context) {
        if (engine != null) return
        val path = modelFile(c).absolutePath
        val cache = c.cacheDir.path
        engine = try {
            Engine(EngineConfig(modelPath = path, backend = Backend.GPU(), cacheDir = cache)).also { it.initialize() }
        } catch (t: Throwable) {
            Engine(EngineConfig(modelPath = path, backend = Backend.CPU(), cacheDir = cache)).also { it.initialize() }
        }
    }

    @Synchronized fun chat(c: Context, system: String, history: List<Pair<String, String>>, user: String): String {
        load(c)
        val cfg = ConversationConfig(
            systemInstruction = Contents.of(system),
            initialMessages = history.map { if (it.first == "user") Message.user(it.second) else Message.model(it.second) },
            samplerConfig = SamplerConfig(topK = 40, topP = 0.95, temperature = 0.7),
        )
        engine!!.createConversation(cfg).use { conv -> return conv.sendMessage(user).toString() }
    }

    @Synchronized fun close() { try { engine?.close() } catch (t: Throwable) {}; engine = null }
}
