package com.example.jarvis

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Date

object Memory {
    const val PERSONA = "Smart, calm, respectful, confident and friendly. Slightly witty when it fits. Emotionally aware, but never claims to know my feelings for sure. Not a customer-service bot."
    private fun p(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun get(c: Context, k: String, d: String) = p(c).getString(k, d) ?: d
    fun set(c: Context, k: String, v: String) = p(c).edit().putString(k, v).apply()
    fun key(c: Context) = get(c, "key", "")
    fun setKey(c: Context, k: String) = set(c, "key", k)
    // Offline AI is used when chosen, or by default when no key is saved.
    fun useLocal(c: Context): Boolean { val e = get(c, "engine", ""); return if (e == "local") true else if (e == "online") false else key(c).isBlank() }

    // ---- MY WORLD ----
    fun entries(c: Context) = JSONArray(get(c, "world", "[]"))
    private fun save(c: Context, a: JSONArray) = set(c, "world", a.toString())
    fun addEntry(c: Context, cat: String, text: String) {
        val a = entries(c)
        a.put(JSONObject().put("id", System.nanoTime()).put("cat", cat).put("text", text)); save(c, a)
    }
    fun editEntry(c: Context, id: Long, cat: String, text: String) {
        val a = entries(c)
        for (i in 0 until a.length()) { val o = a.getJSONObject(i); if (o.getLong("id") == id) o.put("cat", cat).put("text", text) }
        save(c, a)
    }
    fun deleteEntry(c: Context, id: Long) {
        val a = entries(c); val out = JSONArray()
        for (i in 0 until a.length()) { val o = a.getJSONObject(i); if (o.getLong("id") != id) out.put(o) }
        save(c, out)
    }
    fun learn(c: Context, fact: String) { if (fact.isNotBlank()) addEntry(c, "Learned", fact) }
    fun world(c: Context): String {
        val a = entries(c); val sb = StringBuilder()
        for (i in 0 until a.length()) { val o = a.getJSONObject(i); sb.append("- [").append(o.getString("cat")).append("] ").append(o.getString("text")).append('\n') }
        return sb.toString().takeLast(6000).ifBlank { "(nothing saved yet)" }
    }
    fun migrate(c: Context) {   // old v1 "story" box -> one MY WORLD entry
        val s = get(c, "story", "")
        if (s.isNotBlank()) { addEntry(c, "Other", s); p(c).edit().remove("story").apply() }
    }

    // ---- history ----
    fun add(c: Context, role: String, text: String) {
        if (text.isBlank()) return
        File(c.filesDir, "log.txt").appendText("${Date()} [$role] $text\n")
        val h = JSONArray(get(c, "hist", "[]")); h.put(JSONObject().put("role", role).put("content", text))
        val out = JSONArray(); for (i in maxOf(0, h.length() - 40) until h.length()) out.put(h.get(i))
        set(c, "hist", out.toString())
    }
    fun history(c: Context) = JSONArray(get(c, "hist", "[]"))
    fun msgs(c: Context): JSONArray {
        val h = history(c); val out = JSONArray()
        for (i in maxOf(0, h.length() - 16) until h.length()) {
            val m = h.getJSONObject(i)
            if (out.length() == 0 && m.getString("role") != "user") continue
            if (out.length() > 0 && out.getJSONObject(out.length() - 1).getString("role") == m.getString("role")) {
                val last = out.getJSONObject(out.length() - 1)
                last.put("content", last.getString("content") + "\n" + m.getString("content"))
            } else out.put(JSONObject(m.toString()))
        }
        return out
    }

    // ---- privacy ----
    fun clearHistory(c: Context) { p(c).edit().remove("hist").apply(); File(c.filesDir, "log.txt").delete() }
    fun clearWorld(c: Context) { p(c).edit().remove("world").apply() }
    fun clearAll(c: Context) { p(c).edit().clear().apply(); File(c.filesDir, "log.txt").delete() }
}
