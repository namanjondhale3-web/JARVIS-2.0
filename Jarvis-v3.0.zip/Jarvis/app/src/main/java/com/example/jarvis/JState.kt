package com.example.jarvis

import android.os.Handler
import android.os.Looper

object JState {
    var state = "idle"      // idle, listening, thinking, speaking
    var running = false
    var onChange: (() -> Unit)? = null
    private val h = Handler(Looper.getMainLooper())
    fun set(s: String) { state = s; h.post { onChange?.invoke() } }
}
