package com.example.jarvis

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject

class JarvisService : AccessibilityService() {
    companion object { var instance: JarvisService? = null }
    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { instance = null; return super.onUnbind(i) }

    private fun find(pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        fun walk(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (n == null) return null
            if (pred(n)) return n
            for (i in 0 until n.childCount) walk(n.getChild(i))?.let { return it }
            return null
        }
        return walk(rootInActiveWindow)
    }
    private fun label(n: AccessibilityNodeInfo) = "${n.text ?: ""} ${n.contentDescription ?: ""}"

    // What Jarvis "sees": visible texts, marked [tap] / [input].
    fun screen(): String {
        val sb = StringBuilder(); var count = 0
        fun walk(x: AccessibilityNodeInfo?) {
            if (x == null || count > 120) return
            val t = label(x).trim()
            if (t.isNotEmpty() || x.isEditable) {
                sb.append(if (x.isEditable) "[input] " else if (x.isClickable) "[tap] " else "").append(t).append('\n'); count++
            }
            for (i in 0 until x.childCount) walk(x.getChild(i))
        }
        walk(rootInActiveWindow)
        return sb.toString()
    }

    fun open(name: String): String {
        val m = packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .firstOrNull { it.loadLabel(packageManager).toString().contains(name, true) } ?: return "app not found"
        val i = packageManager.getLaunchIntentForPackage(m.activityInfo.packageName) ?: return "cannot open"
        startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "opened"
    }

    fun act(a: JSONObject): String {
        val target = a.optString("target")
        return when (a.optString("type")) {
            "open_app" -> open(target)
            "click" -> find { label(it).contains(target, true) }?.let {
                var n: AccessibilityNodeInfo? = it
                while (n != null && !n.isClickable) n = n.parent
                (n ?: it).performAction(AccessibilityNodeInfo.ACTION_CLICK); "clicked"
            } ?: "not found on screen"
            "type" -> {
                val f = find { it.isEditable && it.isFocused } ?: find { it.isEditable } ?: return "no input field"
                val b = Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, a.optString("text"))
                f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
                if (a.optBoolean("submit") && Build.VERSION.SDK_INT >= 30)
                    f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
                "typed"
            }
            "scroll" -> if (find { it.isScrollable }?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) == true) "scrolled" else "nothing to scroll"
            "back" -> { performGlobalAction(GLOBAL_ACTION_BACK); "back" }
            "home" -> { performGlobalAction(GLOBAL_ACTION_HOME); "home" }
            else -> "unknown action"
        }
    }
}
