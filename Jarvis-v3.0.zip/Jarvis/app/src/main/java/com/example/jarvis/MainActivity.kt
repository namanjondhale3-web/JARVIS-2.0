package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*

class MainActivity : Activity() {
    private val BG = Color.parseColor("#05080f")
    private val CY = Color.parseColor("#00e5ff")
    private val PANEL = Color.parseColor("#0d1626")
    private val cats = listOf("Childhood", "People", "Goals", "Likes", "Fears", "Dates", "Routine", "Fiction", "Other")
    private lateinit var body: FrameLayout
    private var orb: OrbView? = null
    private var status: TextView? = null
    private var chat: TextView? = null
    private var pending: (() -> Unit)? = null
    private var editId = 0L

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(14).toFloat() }
    private fun tv(t: String, size: Float = 15f, color: Int = Color.WHITE) =
        TextView(this).apply { text = t; textSize = size; setTextColor(color) }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.BLACK); background = round(CY); setOnClickListener { f() }
    }
    private fun field(h: String, v: String = "") = EditText(this).apply {
        hint = h; setText(v); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        background = round(PANEL); setPadding(dp(12), dp(10), dp(12), dp(10))
    }
    private fun page(vararg v: View) = ScrollView(this).apply {
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(16))
            v.forEach { addView(it, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(8), 0, 0) }) }
        })
    }
    private fun confirm(msg: String, f: () -> Unit) = AlertDialog.Builder(this).setMessage(msg)
        .setPositiveButton("Yes") { _, _ -> f() }.setNegativeButton("No", null).show()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Memory.migrate(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        body = FrameLayout(this)
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { setBackgroundColor(PANEL) }
        listOf("🏠 Home", "🧠 My World", "⚙ Settings").forEachIndexed { i, t ->
            nav.addView(Button(this).apply {
                text = t; isAllCaps = false; setTextColor(CY); setBackgroundColor(Color.TRANSPARENT); setOnClickListener { show(i) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        show(0)
    }

    override fun onResume() { super.onResume(); JState.onChange = { refresh() }; refresh() }
    override fun onPause() { JState.onChange = null; super.onPause() }

    private fun show(i: Int) {
        body.removeAllViews(); orb = null; status = null; chat = null
        body.addView(when (i) { 0 -> home(); 1 -> world(); else -> settings() })
        refresh()
    }

    private fun refresh() {
        orb?.mode = JState.state
        status?.text = when {
            !JState.running -> "Mic OFF · Jarvis is asleep (Settings → Start)"
            JState.state == "listening" -> "🎤 Listening…"
            JState.state == "thinking" -> "🧠 Thinking…"
            JState.state == "speaking" -> "🔊 Speaking…"
            else -> "🎤 Mic ON · say \"Jarvis\""
        }
        chat?.text = transcript()
    }

    private fun transcript(): String {
        val h = Memory.history(this); val sb = StringBuilder()
        for (i in maxOf(0, h.length() - 8) until h.length()) {
            val m = h.getJSONObject(i)
            sb.append(if (m.getString("role") == "user") "You: " else "Jarvis: ").append(m.getString("content")).append("\n\n")
        }
        return sb.toString()
    }

    private fun toService(extra: Intent.() -> Unit) {
        if (Memory.key(this).isBlank()) { Toast.makeText(this, "Settings mein API key daalo", Toast.LENGTH_LONG).show(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pending = { toService(extra) }
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
            return
        }
        startForegroundService(Intent(this, BrainService::class.java).apply(extra))
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) pending?.invoke()
        pending = null
    }

    // ---------------- HOME ----------------
    private fun home(): View {
        orb = OrbView(this)
        status = tv("", 16f, CY).apply { gravity = Gravity.CENTER }
        chat = tv("", 14f, Color.LTGRAY)
        val input = field("Type to Jarvis…").apply { imeOptions = EditorInfo.IME_ACTION_SEND; setSingleLine() }
        input.setOnEditorActionListener { _, _, _ ->
            val t = input.text.toString().trim()
            if (t.isNotEmpty()) { input.setText(""); toService { putExtra("text", t) } }
            true
        }
        val quick = LinearLayout(this)
        listOf("YouTube", "WhatsApp", "Instagram", "Chrome").forEach { n ->
            quick.addView(btn(n) { toService { putExtra("text", "open $n") } },
                LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        return page(orb!!, status!!, btn("🎤   Tap to talk") { toService { putExtra("mic", true) } }, quick, input, chat!!)
    }

    // ---------------- MY WORLD ----------------
    private fun world(): View {
        val search = field("🔍 Search memories")
        val spin = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, cats) }
        val box = field("Write a memory: who, what, when…").apply { minLines = 3; gravity = Gravity.TOP }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        lateinit var save: Button
        fun render() {
            list.removeAllViews()
            val q = search.text.toString().trim()
            val a = Memory.entries(this)
            for (i in a.length() - 1 downTo 0) {
                val o = a.getJSONObject(i)
                if (q.isNotEmpty() && !(o.getString("text") + " " + o.getString("cat")).contains(q, true)) continue
                val id = o.getLong("id")
                val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = round(PANEL); setPadding(dp(12), dp(10), dp(12), dp(10)) }
                card.addView(tv(o.getString("cat").uppercase(), 11f, CY))
                card.addView(tv(o.getString("text")))
                val row = LinearLayout(this)
                row.addView(Button(this).apply {
                    text = "Edit"; isAllCaps = false
                    setOnClickListener {
                        editId = id; box.setText(o.getString("text"))
                        spin.setSelection(cats.indexOf(o.getString("cat")).coerceAtLeast(0)); save.text = "Update memory"
                    }
                })
                row.addView(Button(this).apply {
                    text = "Delete"; isAllCaps = false
                    setOnClickListener { confirm("Delete this memory?") { Memory.deleteEntry(this@MainActivity, id); render() } }
                })
                card.addView(row)
                list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(8), 0, 0) })
            }
        }
        save = btn("Save memory") {
            val t = box.text.toString().trim()
            if (t.isNotEmpty()) {
                val cat = cats[spin.selectedItemPosition]
                if (editId != 0L) Memory.editEntry(this, editId, cat, t) else Memory.addEntry(this, cat, t)
                editId = 0L; box.setText(""); save.text = "Save memory"; render()
            }
        }
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { render() }
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
        })
        render()
        return page(tv("MY WORLD · Jarvis Memory", 20f, CY),
            tv("Jarvis reads these to know you. Edit or delete anytime. Use Fiction for made-up stories.", 12f, Color.GRAY),
            spin, box, save, search, list)
    }

    // ---------------- SETTINGS ----------------
    private fun settings(): View {
        val key = field("API key (Gemini free or Claude)", Memory.key(this))
        val callme = field("What should Jarvis call you?", Memory.get(this, "callme", "boss"))
        val persona = field("Personality", Memory.get(this, "persona", Memory.PERSONA)).apply { minLines = 3 }
        val langs = listOf("Phone default" to "", "English (India)" to "en-IN", "Hindi" to "hi-IN", "Marathi" to "mr-IN")
        val spin = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, langs.map { it.first })
            setSelection(langs.indexOfFirst { it.second == Memory.get(this@MainActivity, "stt", "") }.coerceAtLeast(0))
        }
        fun saveAll() {
            Memory.setKey(this, key.text.toString().trim())
            Memory.set(this, "callme", callme.text.toString().trim().ifBlank { "boss" })
            Memory.set(this, "persona", persona.text.toString().trim().ifBlank { Memory.PERSONA })
            Memory.set(this, "stt", langs[spin.selectedItemPosition].second)
        }
        val privacy = tv("PRIVACY\n" +
            "• The mic is ON only while the Jarvis notification is showing. Stop Jarvis to turn it off.\n" +
            "• Speech-to-text is done by your phone's Google speech service (it may use Google's servers).\n" +
            "• Only the text of what you say (and screen text during phone tasks) goes to your AI provider.\n" +
            "• Your key, memories and chats are stored on this phone only.", 12f, Color.GRAY)
        return page(
            tv("Settings", 20f, CY), key, callme, persona,
            tv("Speech language (set Marathi/Hindi if Jarvis can't understand you)", 12f, Color.GRAY), spin,
            btn("Save settings") { saveAll(); Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show() },
            btn(if (JState.running) "■ Stop Jarvis" else "▶ Start Jarvis (always listening)") {
                saveAll()
                if (JState.running) { stopService(Intent(this, BrainService::class.java)); JState.running = false; JState.set("idle") }
                else toService { }
                body.postDelayed({ show(2) }, 600)
            },
            btn("1. Enable phone control") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            btn("Battery settings (keep Jarvis alive)") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) },
            privacy,
            btn("Clear chat history") { confirm("Clear all chat history?") { Memory.clearHistory(this); refresh() } },
            btn("Clear MY WORLD memories") { confirm("Delete all memories?") { Memory.clearWorld(this) } },
            btn("Erase everything (incl. key)") { confirm("Erase ALL data?") { Memory.clearAll(this); show(2) } }
        )
    }
}
