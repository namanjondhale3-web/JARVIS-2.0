package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var key: EditText
    private lateinit var story: EditText

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val bg = Color.parseColor("#05080f")
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(bg); setPadding(48, 48, 48, 48)
        }
        fun et(h: String, v: String) = EditText(this).apply {
            hint = h; setText(v); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        }
        fun bt(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        key = et("Anthropic API key", Memory.key(this))
        story = et("Tell Jarvis your story: name, family, work, likes...", Memory.story(this)).apply { minLines = 4 }
        listOf(
            TextView(this).apply { text = "J.A.R.V.I.S"; textSize = 24f; setTextColor(Color.parseColor("#00e5ff")); gravity = Gravity.CENTER },
            key, story,
            bt("Save") { save(); Toast.makeText(this, "Saved, boss", Toast.LENGTH_SHORT).show() },
            bt("1. Enable phone control") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            bt("2. Start Jarvis (say \"Jarvis\")") { start() },
            bt("Stop Jarvis") { stopService(Intent(this, BrainService::class.java)) },
        ).forEach { col.addView(it, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 16, 0, 16) }) }
        setContentView(ScrollView(this).apply { setBackgroundColor(bg); isFillViewport = true; addView(col) })
    }

    private fun save() { Memory.setKey(this, key.text.toString().trim()); Memory.setStory(this, story.text.toString()) }

    private fun start() {
        save()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            startForegroundService(Intent(this, BrainService::class.java))
        else requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) start()
    }
}
