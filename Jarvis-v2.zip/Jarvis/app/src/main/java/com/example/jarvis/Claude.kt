package com.example.jarvis

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Claude {
    fun ask(key: String, system: String, msgs: JSONArray): String {
        val body = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 400)
            .put("system", system).put("messages", msgs)
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("x-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val resp = (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        val j = JSONObject(resp)
        if (!j.has("content")) throw Exception(resp.take(150))
        return j.getJSONArray("content").getJSONObject(0).getString("text")
    }
    fun json(t: String) = JSONObject(t.substring(t.indexOf('{'), t.lastIndexOf('}') + 1))
}
