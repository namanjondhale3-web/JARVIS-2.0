package com.example.jarvis

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Date

object Memory {
    private fun p(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun key(c: Context) = p(c).getString("key", "") ?: ""
    fun setKey(c: Context, k: String) = p(c).edit().putString("key", k).apply()
    fun story(c: Context) = p(c).getString("story", "") ?: ""
    fun setStory(c: Context, s: String) = p(c).edit().putString("story", s.takeLast(4000)).apply()
    fun learn(c: Context, fact: String) { if (fact.isNotBlank()) setStory(c, story(c) + "\n- " + fact) }

    // Saves every exchange forever (log.txt) and keeps the last 40 turns for context.
    fun add(c: Context, role: String, text: String) {
        if (text.isBlank()) return
        File(c.filesDir, "log.txt").appendText("${Date()} [$role] $text\n")
        val h = JSONArray(p(c).getString("hist", "[]")); h.put(JSONObject().put("role", role).put("content", text))
        val out = JSONArray(); for (i in maxOf(0, h.length() - 40) until h.length()) out.put(h.get(i))
        p(c).edit().putString("hist", out.toString()).apply()
    }

    // History shaped for the API: starts with user, roles alternate.
    fun msgs(c: Context): JSONArray {
        val h = JSONArray(p(c).getString("hist", "[]")); val out = JSONArray()
        for (i in 0 until h.length()) {
            val m = h.getJSONObject(i)
            if (out.length() == 0 && m.getString("role") != "user") continue
            if (out.length() > 0 && out.getJSONObject(out.length() - 1).getString("role") == m.getString("role")) {
                val last = out.getJSONObject(out.length() - 1)
                last.put("content", last.getString("content") + "\n" + m.getString("content"))
            } else out.put(JSONObject(m.toString()))
        }
        return out
    }
}
