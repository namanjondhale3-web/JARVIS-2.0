package com.example.jarvis

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import org.json.JSONObject

// Rule-based commands: instant, work offline. Returns text to speak, or null if not a phone command.
object Commands {
    private val OPEN = Regex("""\b(open|launch|start|kholo|khol|chalu|chalao)\b|खोलो|खोल|चालू|चलाओ""")
    private val SEARCH = Regex("""\b(search|find|dhundo|dhoondo)\b|खोजो|सर्च|ढूंढो""")
    private val FILLER = Regex("""\b(for|on|in|at|pe|par|me|mein|karo|kar|do|please|and|aur|the|to|ko|ka|ki|ke)\b|करो|पर|में|और""")
    private val ALIAS = listOf("insta" to "instagram", "yt" to "youtube", "इंस्टाग्राम" to "instagram", "यूट्यूब" to "youtube",
        "व्हाट्सएप" to "whatsapp", "वॉट्सऐप" to "whatsapp", "क्रोम" to "chrome")

    private fun need(hi: Boolean) = if (hi) "पहले Settings में phone control चालू करो।" else "Please enable phone control in Settings first."
    private fun clean(t: String, app: String) =
        t.replace(app.lowercase(), " ").replace(OPEN, " ").replace(FILLER, " ").replace(Regex("\\s+"), " ").trim()

    fun run(ctx: Context, svc: JarvisService?, said: String): String? {
        var low = said.lowercase().trim()
        for ((a, b) in ALIAS) low = low.replace(Regex("(?<![a-z0-9])" + Regex.escape(a) + "(?![a-z0-9])"), b).replace(a, b)
        val hi = said.any { it in '\u0900'..'\u097F' }
        fun say(en: String, h: String) = if (hi) h else en

        if (low.split(Regex("\\s+")).size <= 3) {
            val g = when {
                Regex("""\b(back|peeche)\b|वापस|पीछे""").containsMatchIn(low) -> "back"
                Regex("""\b(home|ghar)\b|होम""").containsMatchIn(low) -> "home"
                Regex("""\bscroll\b|स्क्रॉल""").containsMatchIn(low) -> "scroll"
                else -> null
            }
            if (g != null) { if (svc == null) return need(hi); svc.act(JSONObject().put("type", g)); return say("Done.", "हो गया।") }
        }

        val pm = ctx.packageManager
        val labels = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() }.filter { it.length >= 3 }
        val app = labels.filter { Regex("(?<![a-z0-9])" + Regex.escape(it.lowercase()) + "(?![a-z0-9])").containsMatchIn(low) }
            .maxByOrNull { it.length } ?: return null

        val s = SEARCH.find(low)
        if (s == null && !OPEN.containsMatchIn(low)) return null
        var q = ""
        if (s != null) {
            q = clean(low.substring(s.range.last + 1), app)
            if (q.isBlank()) q = clean(low.substring(0, s.range.first), app)
        }
        if (svc == null) return need(hi)
        val r = svc.open(app)
        if (r != "opened") return say("I couldn't open $app. Please allow 'Display over other apps' for Jarvis in Settings.",
            "$app नहीं खुल पाया। Settings में 'Display over other apps' की permission दो।")
        if (q.isNotBlank()) Handler(Looper.getMainLooper()).postDelayed({ svc.searchIn(q) }, 2500)
        return if (q.isBlank()) say("Opening $app.", "$app खोल रहा हूँ।") else say("Opening $app and searching $q.", "$app खोलकर $q सर्च कर रहा हूँ।")
    }
}
