package com.example.jarvis

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.sin

class OrbView(c: Context, hDp: Int = 260) : View(c) {
    var mode = "idle"
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmp: Bitmap = BitmapFactory.decodeResource(c.resources, R.drawable.reactor)
    private var t = 0f
    private var angle = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1600; repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            t = it.animatedValue as Float
            angle += when (mode) { "listening" -> 2f; "thinking" -> 6f; "speaking" -> 3f; else -> 0.5f }
            invalidate()
        }
    }
    init { minimumHeight = (hDp * c.resources.displayMetrics.density).toInt() }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val r = minOf(cx, cy) * 0.5f
        val pulse = (sin(t * 2 * Math.PI) * 0.5 + 0.5).toFloat()
        val amp = when (mode) { "idle" -> 0.04f; "thinking" -> 0.06f; else -> 0.16f }
        val rr = r * (1f + amp * pulse)
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, rr * 1.9f,
            intArrayOf(0x8800E5FF.toInt(), 0x2200E5FF, 0x0000E5FF), floatArrayOf(0.3f, 0.7f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, rr * 1.9f, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.color = Color.parseColor("#00e5ff")
        p.strokeWidth = 4f; cv.drawCircle(cx, cy, rr, p)
        p.alpha = 120; p.strokeWidth = 2f; cv.drawCircle(cx, cy, rr * 1.3f, p)
        p.alpha = 255; p.strokeWidth = 7f
        val rect = RectF(cx - rr * 0.8f, cy - rr * 0.8f, cx + rr * 0.8f, cy + rr * 0.8f)
        for (k in 0 until 3) cv.drawArc(rect, angle + k * 120f, 60f, false, p)
        val s = rr * 0.62f * (1f + 0.06f * pulse)
        cv.drawBitmap(bmp, null, RectF(cx - s, cy - s, cx + s, cy + s), null)
    }
}
